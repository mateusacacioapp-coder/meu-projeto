-- Execute este script no SQL Editor do Supabase antes de conectar o sistema.
create extension if not exists pgcrypto;

create table if not exists public.records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  origin text not null default 'manual' check (origin in ('manual','bi')),
  load_number text,
  load_date date,
  customer text not null,
  city text,
  order_number text,
  quantity numeric(14,2) default 0,
  weight numeric(14,2) default 0,
  route text,
  routing_status text,
  representative text,
  channel text,
  priority text,
  client_code text,
  oct numeric,
  oct_range text,
  order_entry_date date,
  commercial_date date,
  order_type text,
  haver text,
  cost_center text,
  billing_forecast date,
  load_link text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists records_user_load_idx on public.records(user_id, load_number);
create index if not exists records_user_date_idx on public.records(user_id, load_date);
create index if not exists records_user_customer_idx on public.records(user_id, customer);

create table if not exists public.import_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  file_name text not null,
  rows_count integer not null default 0,
  created_at timestamptz not null default now()
);

alter table public.records enable row level security;
alter table public.import_runs enable row level security;

drop policy if exists "Users manage their own records" on public.records;
create policy "Users manage their own records" on public.records
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users read own import history" on public.import_runs;
create policy "Users read own import history" on public.import_runs
  for select using (auth.uid() = user_id);
drop policy if exists "Users insert own import history" on public.import_runs;
create policy "Users insert own import history" on public.import_runs
  for insert with check (auth.uid() = user_id);

-- Substituição atômica: se qualquer etapa falhar, o banco mantém a carteira anterior.
-- Apenas registros com origin='bi' do usuário autenticado são removidos.
create or replace function public.replace_bi_records(p_rows jsonb, p_file_name text)
returns void
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_count integer;
begin
  if auth.uid() is null then
    raise exception 'Usuário não autenticado.';
  end if;
  if jsonb_typeof(p_rows) <> 'array' then
    raise exception 'O conteúdo da importação deve ser uma lista.';
  end if;
  v_count := jsonb_array_length(p_rows);
  if v_count = 0 or v_count > 25000 then
    raise exception 'Quantidade de linhas inválida (limite: 25.000).';
  end if;

  delete from public.records where user_id = auth.uid() and origin = 'bi';

  insert into public.records (
    user_id, origin, load_number, load_date, customer, city, order_number,
    quantity, weight, route, routing_status, representative, channel, priority,
    client_code, oct, oct_range, order_entry_date, commercial_date, order_type,
    haver, cost_center, billing_forecast, load_link
  )
  select auth.uid(), 'bi', x.load_number, x.load_date, x.customer, x.city,
    x.order_number, coalesce(x.quantity,0), coalesce(x.weight,0), x.route,
    x.routing_status, x.representative, x.channel, x.priority, x.client_code,
    x.oct, x.oct_range, x.order_entry_date, x.commercial_date, x.order_type,
    x.haver, x.cost_center, x.billing_forecast, x.load_link
  from jsonb_to_recordset(p_rows) as x(
    load_number text, load_date date, customer text, city text, order_number text,
    quantity numeric, weight numeric, route text, routing_status text,
    representative text, channel text, priority text, client_code text, oct numeric,
    oct_range text, order_entry_date date, commercial_date date, order_type text,
    haver text, cost_center text, billing_forecast date, load_link text
  )
  where nullif(trim(x.customer),'') is not null;

  insert into public.import_runs(user_id, file_name, rows_count)
  values(auth.uid(), coalesce(nullif(p_file_name,''),'Importação Excel'), v_count);
end;
$$;

-- O Supabase Auth controla a criação e autenticação das contas individuais.
